

import org.example.Main;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class MainTest {
    @Test
    void testMain() {
        String input = "茅台最新研报[report-id:1],{table:[h1,h2,h3],[t1,t2,t3]},{table:[h1,h2],[t1,t2]}显示股价太高了。";

        Main.main(new String[0])
    }
}
